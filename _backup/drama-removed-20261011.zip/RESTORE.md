# 拍短剧页面删除备份（2026-10-11）

这个 zip 里是**删除拍短剧页面之前**的工作区状态原文，含当时尚未提交的改动。
备份时间：2026-10-11 21:5x（Asia/Shanghai）
仓库：`C:\Users\ycwb\Desktop\aii`，分支 `main`，基线提交 `70532de`

## 里面有什么

| 文件 | 大小 | 说明 |
| --- | --- | --- |
| `drama.html` | 449,779 字节 | 拍短剧页面本体（内联脚本 + 界面）。已整页删除。 |
| `drama.js` | 328,026 字节 | 原模块。删净拍短剧专属代码后改名 `chars.js`（素材库后端）。 |
| `RESTORE.md` | — | 本文件。 |

## 怎么还原

整个 zip 解到仓库根目录即可覆盖回原样（`drama.html` 回到原位，`drama.js` 回到原位）。

但**光覆盖这两个文件不等于还原**：删除那一轮同时改过下列文件，只还原 drama.* 会让项目处于半新半旧的状态。

- `app.js` — `PAGES` 里的 `drama.html` 条目
- `sidebar.js` — 侧栏「拍短剧」项
- `shell.html` — 按需加载列表里的 `drama.js`
- `chars.html` / `director.html` / `settings.html` / `ai-chat.js` — 全局 `window.Drama` 改名与拍短剧分支清理
- `ui.js` — 同步白名单
- `assetlib.js` — 提示词表
- `ui.css` / `.gitignore`
- `tests/selfcheck.cjs` / `tests/mutation.cjs` — 自测档位与变异锚点
- `AGENTS.md` / `README.md` / `docs/*.md`

**要完整回到删除前的样子，用 git 回到当时的提交更省事**：

```bash
git stash list                 # 先看有没有别的在飞
git log --oneline -1           # 确认基线
git checkout -- .              # 丢弃全部未提交改动（会一并丢掉删除后的改动）
```

⚠️ 注意：删除那一轮开始前工作区本来就有 16 个文件的未提交改动
（`AGENTS.md` / `README.md` / `ai-chat.js` / `assetlib.js` / `assets.html` / `chars.html` /
`director.html` / `drama.js` / `proxy.js` / `studio.html` / `tests/selfcheck.cjs` /
`ui.css` / `ui.js` / `workbench.js`，外加未跟踪的 `docs/`）。
`git checkout -- .` 会把**那些改动一起丢掉**。这个 zip 只覆盖 drama.* 两份，
不覆盖那批未提交改动 —— 那批的还原请依靠你自己的备份或 stash。

## 只想拿回拍短剧功能（保留后续的瘦身/改名）

不能只覆盖这两个文件。`drama.js` 里的 `Subs`（字幕轨）、`Shots`（剧集镜头增删改）、
拆剧本 / 拍摄循环 / 成片 EDL、以及 `SET` 里的
`durMin` / `aiDur` / `inherit` / `maxTakes` / `camN` 已在瘦身时删除，
拍短剧页依赖它们。还原 = 用这里的 `drama.js` 换回现在的 `chars.js`，
并把上面列的那些文件的拍短剧分支一并加回来。

## 为什么 `proxy.js` 的 `/render` 还在

`/render` 不是拍短剧专属：导演台（`director.html`）的「合并全片 / 全片导出」走的是同一组路由
（`/render`、`/render/status`、`/render/play`、`/render/dl`、`/render/cancel`），
所以代理这一侧一行没删。字幕烧录能力（`clips[].subs`）随之保留。

## 为什么存的是当前状态而不是 HEAD

删除开始前工作区有 16 个文件未提交。只抓 `git show HEAD:drama.js` 的话，
拿回来的是一份**旧的** drama.js，覆盖回去等于丢掉本轮已有的改动。
这个 zip 是直接从工作区复制的。
